const productos = [
    {
        id: 1,
        nombre: "Harina",
        precio: 50,
        img:
            "https://static9.depositphotos.com/1588534/1102/i/600/depositphotos_11024084-stock-photo-wheat-grain-and-flour.jpg",
        cantidad: 1,
    },
    {
        id: 2,
        nombre: "Galletitas",
        precio: 100,
        img:
            "https://clarin.com/img//2020/09/07/hGBJSRQ0d_340x340__1.jpg",
        cantidad: 1,
    },
    {
        id: 3,
        nombre: "Cerveza",
        precio: 150,
        img:
            "https://www.shutterstock.com/image-photo/cold-bottles-beer-bucket-on-260nw-1396469039.jpg",
        cantidad: 1,
    },
    {
        id: 4,
        nombre: "Leche",
        precio: 200,
        img:
            "https://www.webconsultas.com/sites/default/files/styles/wch_image_schema/public/articulos/tipos-leche.jpg",
        cantidad: 1,
    }
];